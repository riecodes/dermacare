<?php

    $database= new mysqli("localhost","u747739612_dermacarenew","Dermacarenew1!","u747739612_derma");
    if ($database->connect_error){
        die("Connection failed:  ".$database->connect_error);
    }

?>